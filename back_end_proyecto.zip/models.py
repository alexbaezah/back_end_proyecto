# 0. ejecutamos pip install flask flask-sqlalchemy flask-migrate flask-cors



from xmlrpc.client import Boolean
from flask import Flask, request, jsonify
from flask_migrate import Migrate
from models import db, Usuario
from flask_cors import CORS, cross_origin

class Region(db.Model):
    __tablename__ ='Region'
    id = db.Column(db.Integer, primary_key = True)
    nombre = db.Column(db.String(250), nullable = False)
    comunas = db.relationship('Comuna', backref = 'region')

    def serialize(self):
        return{
            "id": self.id,
            "nombre": self.nombre
        }
    
    def save(self):
        db.session.add(self)
        db.session.commit()

    def update(self):
        db.session.commit()
    
    def delete(self):
        db.session.delete(self)
        db.session.commit()
    
class Comuna(db.Model):
    __tablename__ = 'Comuna'
    id = db.Column(db.Integer, primary_key = True)
    nombre = db.Column(db.String(250), nullable = False)
    region_id = db.Column(db.integer, db.ForeignKey('region.id'))

    def serialize(self):
        return{
            "id": self.id,
            "nombre": self.nombre
            #"region_id" : 
        }
    
    def save(self):
        db.session.add(self)
        db.session.commit()


class Cliente(db.Model):
    id = db.Column(db.Integer, primary_key = True)
    rut = db.Column(db.Integer, unique = True, nullable = False)
    dv = db.Column(db.String(1), nullable = False)
    primer_nombre = db.Column(db.String(250), nullable= False)
    segundo_nombre = db.Column(db.String(250), nullable= True)
    apellido_paterno = db.Column(db.String(250), nullable= False)
    apellido_materno = db.Column(db.String(250), nullable= True)
    direccion = db.Column(db.String(250), nullable= False)
    telefono = db.Column(db.Integer, nullable = False)
    correo = db.Column(db.String(250), nullable = False)
    #estado = 
    comuna_id = db.column(db.integer, db.ForeignKey('comuna.id'))

class Despacho(db.Model)
    __tablename__ = 'Despacho'
    id = db.Column(db.Integer, primary_key = True)
    direccion = db.Column(db.String(250), nullable = False)
    fecha_entrega = db.Column(db.DateTime, nullable = False)
    hora_entrega = db.Column(db.DateTime, nullable = False)
    rut_recibe = db.Column(String(11), nullable = False)
    nombre_recibe = db.Column(String(250), nullable = False)
    estado_despacho = db.Column(Boolean, nullable = False, default = False)
    




